package mx.edu.utez.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCanvasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCanvasApplication.class, args);
	}

}
